-- =====================================================================
-- Mimiq database for Supabase
-- Paste this whole file into Supabase > SQL Editor > New query, then Run.
-- Safe to run again later: it updates the functions and keeps your data.
--
-- How it's protected: all tables live in the private "hive" schema, which
-- the website can't read or write directly. The website can only call the
-- public.hive_* functions below, which enforce every rule (voting, XP,
-- bad words, who can see which bot).
-- =====================================================================

create extension if not exists pg_trgm with schema extensions;
create schema if not exists hive;

-- ============================ TABLES ============================

create table if not exists hive.profiles (
  id              uuid primary key references auth.users(id) on delete cascade,
  username        text        not null,
  friend_code     text        not null unique,
  xp              int         not null default 0,
  streak          int         not null default 0,
  last_active_day date,
  tz              text        not null default 'UTC',
  theme           text        not null default 'cyan',
  avatar          text        not null default 'hex',
  sound           boolean     not null default true,
  taught          int         not null default 0,
  bounties        int         not null default 0,
  votes_cast      int         not null default 0,
  changes         int         not null default 0,
  created_at      timestamptz not null default now()
);
create unique index if not exists profiles_username_idx on hive.profiles (lower(username));

-- Friendships are stored in both directions.
create table if not exists hive.friends (
  user_id    uuid not null references hive.profiles(id) on delete cascade,
  friend_id  uuid not null references hive.profiles(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (user_id, friend_id)
);

-- Every taught answer. bot = public | private | friend.
create table if not exists hive.answers (
  id          bigint generated always as identity primary key,
  bot         text        not null check (bot in ('public', 'private', 'friend')),
  prompt_key  text        not null,
  prompt_text text        not null,
  answer      text        not null,
  author_id   uuid        not null references hive.profiles(id) on delete cascade,
  editor_id   uuid        references hive.profiles(id) on delete set null,
  uses        int         not null default 0,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);
create index if not exists answers_lookup_idx on hive.answers (bot, prompt_key);
create unique index if not exists answers_public_unique on hive.answers (prompt_key) where bot = 'public';
create unique index if not exists answers_private_unique on hive.answers (author_id, prompt_key) where bot = 'private';
create unique index if not exists answers_friend_unique on hive.answers (author_id, prompt_key) where bot = 'friend';

create table if not exists hive.answer_history (
  id         bigint generated always as identity primary key,
  answer_id  bigint      not null references hive.answers(id) on delete cascade,
  old_answer text        not null,
  changed_by uuid        not null references hive.profiles(id) on delete cascade,
  changed_at timestamptz not null default now()
);

create table if not exists hive.votes (
  user_id   uuid   not null references hive.profiles(id) on delete cascade,
  answer_id bigint not null references hive.answers(id) on delete cascade,
  value     int    not null check (value in (-1, 1)),
  primary key (user_id, answer_id)
);

-- The answer a user must vote on before asking that bot something new.
create table if not exists hive.pending_votes (
  user_id   uuid   not null references hive.profiles(id) on delete cascade,
  bot       text   not null,
  answer_id bigint not null,
  primary key (user_id, bot)
);

-- Public prompts nobody has taught yet.
create table if not exists hive.bounties (
  prompt_key     text        primary key,
  prompt_text    text        not null,
  asks           int         not null default 1,
  first_asker_id uuid,
  last_asked     timestamptz not null default now()
);

create table if not exists hive.xp_log (
  id         bigint generated always as identity primary key,
  user_id    uuid        not null references hive.profiles(id) on delete cascade,
  amount     int         not null,
  reason     text        not null,
  created_at timestamptz not null default now()
);
create index if not exists xp_log_time_idx on hive.xp_log (created_at);

create table if not exists hive.achievements (
  user_id   uuid        not null references hive.profiles(id) on delete cascade,
  code      text        not null,
  earned_at timestamptz not null default now(),
  primary key (user_id, code)
);

alter table hive.profiles       enable row level security;
alter table hive.friends        enable row level security;
alter table hive.answers        enable row level security;
alter table hive.answer_history enable row level security;
alter table hive.votes          enable row level security;
alter table hive.pending_votes  enable row level security;
alter table hive.bounties       enable row level security;
alter table hive.xp_log         enable row level security;
alter table hive.achievements   enable row level security;

-- ============================ GAME DATA ============================

create or replace function hive.theme_defs() returns jsonb language sql immutable as $$
  select '[
    {"id":"cyan",    "name":"Neon Cyan",      "level":1},
    {"id":"magenta", "name":"Synth Magenta",  "level":2},
    {"id":"lime",    "name":"Toxic Lime",     "level":4},
    {"id":"gold",    "name":"Solar Gold",     "level":6},
    {"id":"plasma",  "name":"Plasma Rainbow", "level":10}
  ]'::jsonb
$$;

create or replace function hive.avatar_defs() returns jsonb language sql immutable as $$
  select '[
    {"id":"hex",   "name":"Mirror M",  "level":1},
    {"id":"orb",   "name":"Pulse Orb", "level":2},
    {"id":"eye",   "name":"Watcher",   "level":3},
    {"id":"cube",  "name":"Data Cube", "level":5},
    {"id":"star",  "name":"Nova",      "level":8},
    {"id":"crown", "name":"Mimic King", "level":12}
  ]'::jsonb
$$;

create or replace function hive.achievement_defs() returns jsonb language sql immutable as $$
  select '[
    {"code":"first_words",      "icon":"🐣", "name":"First Words",      "desc":"Teach your first answer"},
    {"code":"teacher_10",       "icon":"📚", "name":"Teacher",          "desc":"Teach 10 answers"},
    {"code":"know_it_all",      "icon":"🧠", "name":"Know-It-All",      "desc":"Teach 100 answers"},
    {"code":"bounty_hunter",    "icon":"🎯", "name":"Bounty Hunter",    "desc":"Claim 5 bounties"},
    {"code":"first_friend",     "icon":"🤝", "name":"Buddy Up",         "desc":"Add your first friend"},
    {"code":"social_butterfly", "icon":"🦋", "name":"Social Butterfly", "desc":"Have 5 friends"},
    {"code":"critic",           "icon":"⚖️", "name":"The Critic",       "desc":"Vote on 50 answers"},
    {"code":"crowd_fav",        "icon":"⭐", "name":"Crowd Favorite",   "desc":"Get 10 upvotes on one answer"},
    {"code":"fixer",            "icon":"🔧", "name":"The Fixer",        "desc":"Change 10 answers"},
    {"code":"night_owl",        "icon":"🦉", "name":"Night Owl",        "desc":"Teach something between midnight and 4am"},
    {"code":"streak_3",         "icon":"🔥", "name":"On Fire",          "desc":"Reach a 3-day streak"},
    {"code":"streak_7",         "icon":"☄️", "name":"Unstoppable",      "desc":"Reach a 7-day streak"},
    {"code":"streak_30",        "icon":"🌋", "name":"Legend",           "desc":"Reach a 30-day streak"},
    {"code":"level_5",          "icon":"🚀", "name":"Liftoff",          "desc":"Reach level 5"},
    {"code":"level_10",         "icon":"👑", "name":"Mimiq Royalty",    "desc":"Reach level 10"}
  ]'::jsonb
$$;

create or replace function hive.blocked_msg() returns text language sql immutable as $$
  select '🚫 Whoa, let''s keep Mimiq clean! That has a blocked word in it.'
$$;

create or replace function hive.level_for(p_xp int) returns int language sql immutable as $$
  select floor(sqrt(greatest(p_xp, 0) / 50.0))::int + 1
$$;

create or replace function hive.xp_for_level(p_level int) returns int language sql immutable as $$
  select 50 * (p_level - 1) * (p_level - 1)
$$;

-- ============================ BAD-WORD BLOCKER ============================
-- Catches leetspeak (sh1t), masked letters (f*ck), stretched letters (fuuuck)
-- and spaced-out letters (f u c k). Edit these two lists to change what's blocked.

-- Blocked anywhere inside a word ("fucking", "bullshit").
create or replace function hive.bad_stems() returns text[] language sql immutable as $$
  select array['fuck', 'shit', 'bitch', 'cunt', 'nigger', 'nigga', 'faggot', 'whore', 'slut',
               'motherf', 'asshole', 'wanker', 'dickhead', 'cocksuck', 'jackass', 'dumbass', 'bullshit']
$$;

-- Blocked only as whole words (so "class", "cockpit" and "Dickens" are fine).
create or replace function hive.bad_words() returns text[] language sql immutable as $$
  select array['fuk', 'fuking', 'fck', 'fcking', 'ass', 'asses', 'arse', 'dick', 'dicks', 'cock', 'cocks',
               'fag', 'fags', 'prick', 'pricks', 'piss', 'pissed', 'twat', 'retard', 'retards', 'retarded',
               'tits', 'titties', 'porn', 'porno', 'cum', 'jizz', 'dildo', 'bollocks', 'bastard', 'bastards',
               'pussy', 'pussies', 'wtf', 'stfu', 'milf', 'thot', 'kys', 'boner', 'horny', 'nudes']
$$;

-- A letter after the first may be swapped for a mask symbol: f*ck, sh#t.
create or replace function hive.maskify(p_word text) returns text language sql immutable as $$
  select left(p_word, 1) || coalesce(string_agg('[' || c || '*#%]', '' order by i), '')
  from unnest(string_to_array(substr(p_word, 2), null)) with ordinality as x(c, i)
$$;

create or replace function hive.has_bad_words(p_text text) returns boolean language plpgsql stable as $$
declare
  v_stem_re text := (select string_agg(hive.maskify(s), '|') from unnest(hive.bad_stems()) s);
  v_word_re text := '^(' || (select string_agg(hive.maskify(s), '|') from unnest(hive.bad_words()) s) || ')$';
  v_base    text := translate(lower(coalesce(p_text, '')), '013457!|@$+', 'oieastiiast');
  v_tokens  text[] := '{}';
  v_buf     text := '';
  v_tok     text;
  v_item    text;
  v_form    text;
begin
  -- Split into words, joining runs of single letters ("f u c k" -> "fuck").
  foreach v_tok in array regexp_split_to_array(v_base, '[^a-z*#%]+') loop
    if length(v_tok) = 1 then
      v_buf := v_buf || v_tok;
    else
      if length(v_buf) >= 3 then v_tokens := v_tokens || v_buf; end if;
      v_buf := '';
      if v_tok <> '' then v_tokens := v_tokens || v_tok; end if;
    end if;
  end loop;
  if length(v_buf) >= 3 then v_tokens := v_tokens || v_buf; end if;

  foreach v_item in array array[v_base] || v_tokens loop
    foreach v_form in array array[
      v_item,
      regexp_replace(v_item, '([a-z])\1{2,}', '\1\1', 'g'),  -- fuuuuck -> fuuck
      regexp_replace(v_item, '([a-z])\1{2,}', '\1', 'g')     -- fuuuuck -> fuck
    ] loop
      if v_form ~ v_stem_re or v_form ~ v_word_re then return true; end if;
    end loop;
  end loop;
  return false;
end $$;

-- ============================ HELPERS ============================

-- "What's  UP??" -> "whats up" so small differences still match.
create or replace function hive.prompt_key(p_text text) returns text language sql immutable as $$
  select btrim(regexp_replace(regexp_replace(lower(p_text), '[''’`]', '', 'g'), '[^[:alnum:]]+', ' ', 'g'))
$$;

create or replace function hive.clean_text(p_text text, p_max int, p_label text, p_multiline boolean default false)
returns text language plpgsql immutable as $$
declare
  v_text text := btrim(replace(coalesce(p_text, ''), E'\r', ''), E' \t\n');
begin
  if p_multiline then
    v_text := regexp_replace(v_text, E'\n{3,}', E'\n\n', 'g');
  else
    v_text := regexp_replace(v_text, '\s+', ' ', 'g');
  end if;
  if v_text = '' then raise exception '% can''t be empty', p_label; end if;
  if length(v_text) > p_max then raise exception '% is too long (max % characters)', p_label, p_max; end if;
  return v_text;
end $$;

create or replace function hive.check_bot(p_bot text) returns void language plpgsql immutable as $$
begin
  if p_bot is null or p_bot not in ('public', 'private', 'friend') then raise exception 'Unknown bot'; end if;
end $$;

create or replace function hive.require_user() returns uuid language plpgsql stable as $$
declare
  v_uid uuid := auth.uid();
begin
  if v_uid is null or not exists (select 1 from hive.profiles where id = v_uid) then
    raise exception 'Please sign in';
  end if;
  return v_uid;
end $$;

create or replace function hive.new_friend_code() returns text language plpgsql volatile as $$
declare
  v_chars text := 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  v_code  text;
begin
  loop
    v_code := 'MIMIQ-' || (select string_agg(substr(v_chars, 1 + floor(random() * length(v_chars))::int, 1), '')
                          from generate_series(1, 5));
    exit when not exists (select 1 from hive.profiles where friend_code = v_code);
  end loop;
  return v_code;
end $$;

-- ----- events: what the website should celebrate (XP, level ups, achievements) -----
create or replace function hive._ev() returns jsonb language sql stable as $$
  select coalesce(nullif(current_setting('hive.ev', true), '')::jsonb,
    '{"xp":0,"levelUp":null,"unlocks":[],"achievements":[],"streak":null,"bountyClaimed":false}'::jsonb)
$$;

create or replace function hive._ev_set(p_ev jsonb) returns void language plpgsql as $$
begin
  perform set_config('hive.ev', p_ev::text, true);
end $$;

create or replace function hive._ev_reset() returns void language plpgsql as $$
begin
  perform set_config('hive.ev', '', true);
end $$;

-- ----- XP and achievements -----
create or replace function hive.add_xp(p_user uuid, p_amount int, p_reason text) returns void language plpgsql as $$
declare
  v_before int;
  v_from   int;
  v_to     int;
  v_ev     jsonb;
  v_unlocks jsonb;
begin
  update hive.profiles set xp = xp + p_amount where id = p_user returning xp - p_amount into v_before;
  insert into hive.xp_log (user_id, amount, reason) values (p_user, p_amount, p_reason);
  v_from := hive.level_for(v_before);
  v_to := hive.level_for(v_before + p_amount);
  if p_user = auth.uid() then
    v_ev := hive._ev();
    v_ev := jsonb_set(v_ev, '{xp}', to_jsonb((v_ev->>'xp')::int + p_amount));
    if v_to > v_from then
      select coalesce(jsonb_agg(jsonb_build_object('kind', kind, 'name', d->>'name')), '[]'::jsonb) into v_unlocks
      from (
        select 'theme' as kind, d from jsonb_array_elements(hive.theme_defs()) d
        union all
        select 'avatar', d from jsonb_array_elements(hive.avatar_defs()) d
      ) u
      where (d->>'level')::int > v_from and (d->>'level')::int <= v_to;
      v_ev := jsonb_set(v_ev, '{levelUp}', to_jsonb(v_to));
      v_ev := jsonb_set(v_ev, '{unlocks}', (v_ev->'unlocks') || v_unlocks);
    end if;
    perform hive._ev_set(v_ev);
  end if;
  if v_to >= 5 then perform hive.award(p_user, 'level_5'); end if;
  if v_to >= 10 then perform hive.award(p_user, 'level_10'); end if;
end $$;

create or replace function hive.award(p_user uuid, p_code text) returns void language plpgsql as $$
declare
  v_ev jsonb;
begin
  insert into hive.achievements (user_id, code) values (p_user, p_code) on conflict do nothing;
  if not found then return; end if;
  if p_user = auth.uid() then
    v_ev := hive._ev();
    v_ev := jsonb_set(v_ev, '{achievements}', (v_ev->'achievements') || coalesce(
      (select jsonb_agg(d) from jsonb_array_elements(hive.achievement_defs()) d where d->>'code' = p_code), '[]'::jsonb));
    perform hive._ev_set(v_ev);
  end if;
  perform hive.add_xp(p_user, 25, 'achievement:' || p_code);
end $$;

create or replace function hive.touch_streak(p_user uuid) returns void language plpgsql as $$
declare
  v_p      hive.profiles;
  v_today  date;
  v_streak int;
begin
  select * into v_p from hive.profiles where id = p_user for update;
  v_today := (now() at time zone v_p.tz)::date;
  if v_p.last_active_day = v_today then return; end if;
  v_streak := case when v_p.last_active_day = v_today - 1 then v_p.streak + 1 else 1 end;
  update hive.profiles set streak = v_streak, last_active_day = v_today where id = p_user;
  perform hive._ev_set(jsonb_set(hive._ev(), '{streak}', to_jsonb(v_streak)));
  perform hive.add_xp(p_user, 5 + case v_streak when 3 then 20 when 7 then 50 when 14 then 100
                                                 when 30 then 200 when 100 then 500 else 0 end, 'daily');
  if v_streak >= 3 then perform hive.award(p_user, 'streak_3'); end if;
  if v_streak >= 7 then perform hive.award(p_user, 'streak_7'); end if;
  if v_streak >= 30 then perform hive.award(p_user, 'streak_30'); end if;
end $$;

-- ----- answers -----
create or replace function hive.can_see(p_bot text, p_author uuid, p_user uuid) returns boolean language sql stable as $$
  select p_bot = 'public' or p_author = p_user
      or (p_bot = 'friend' and exists (select 1 from hive.friends where user_id = p_user and friend_id = p_author))
$$;

create or replace function hive.find_answer(p_user uuid, p_bot text, p_key text) returns hive.answers language sql stable as $$
  select a.* from hive.answers a
  where a.bot = p_bot and a.prompt_key = p_key and hive.can_see(a.bot, a.author_id, p_user)
  order by (select coalesce(sum(v.value), 0) from hive.votes v where v.answer_id = a.id) desc, a.updated_at desc
  limit 1
$$;

create or replace function hive.tally(p_answer bigint, out up int, out down int) language sql stable as $$
  select count(*) filter (where value = 1)::int, count(*) filter (where value = -1)::int
  from hive.votes where answer_id = p_answer
$$;

create or replace function hive.answer_view(p_a hive.answers, p_user uuid) returns jsonb language plpgsql stable as $$
declare
  v_up   int;
  v_down int;
  v_mine int;
begin
  select t.up, t.down into v_up, v_down from hive.tally(p_a.id) t;
  select value into v_mine from hive.votes where user_id = p_user and answer_id = p_a.id;
  return jsonb_build_object(
    'id', p_a.id,
    'bot', p_a.bot,
    'prompt', p_a.prompt_text,
    'text', p_a.answer,
    'author', (select username from hive.profiles where id = p_a.author_id),
    'editor', (select username from hive.profiles where id = p_a.editor_id),
    'uses', p_a.uses,
    'up', v_up,
    'down', v_down,
    'myVote', coalesce(v_mine, 0),
    'best', v_up >= 5 and v_up >= v_down * 3);
end $$;

create or replace function hive.suggestions(p_user uuid, p_bot text, p_key text) returns jsonb language sql stable as $$
  select coalesce(jsonb_agg(jsonb_build_object('prompt', prompt_text) order by score desc), '[]'::jsonb)
  from (
    select prompt_text, score from (
      select distinct on (a.prompt_key) a.prompt_text, extensions.similarity(a.prompt_key, p_key) as score
      from hive.answers a
      where a.bot = p_bot
        and hive.can_see(a.bot, a.author_id, p_user)
        and abs(length(a.prompt_key) - length(p_key)) <= greatest(3, ceil(length(p_key) * 0.4))
      order by a.prompt_key
    ) d
    where score >= 0.45
    order by score desc
    limit 3
  ) s
$$;

create or replace function hive.count_for(p_user uuid, p_bot text) returns int language sql stable as $$
  select count(*)::int from hive.answers a where a.bot = p_bot and hive.can_see(a.bot, a.author_id, p_user)
$$;

-- An answer is voted out once it has 3+ votes and its downvotes are more than 33% higher than its upvotes.
create or replace function hive.is_voted_out(p_up int, p_down int) returns boolean language sql immutable as $$
  select p_up + p_down >= 3 and p_down > p_up * 1.33
$$;

create or replace function hive.delete_answer(p_a hive.answers) returns void language plpgsql as $$
begin
  delete from hive.answers where id = p_a.id;
  delete from hive.pending_votes where answer_id = p_a.id;
  if p_a.bot = 'public' then
    -- Back on the bounty board so someone can teach a better answer.
    insert into hive.bounties (prompt_key, prompt_text, asks, first_asker_id, last_asked)
    values (p_a.prompt_key, p_a.prompt_text, 1, null, now())
    on conflict (prompt_key) do update set last_asked = excluded.last_asked;
  end if;
end $$;

create or replace function hive.change_answer(p_user uuid, p_answer_id bigint, p_text text) returns jsonb language plpgsql as $$
declare
  v_text text := hive.clean_text(p_text, 1000, 'Answer', true);
  v_a    hive.answers;
  v_n    int;
begin
  if hive.has_bad_words(v_text) then raise exception '%', hive.blocked_msg(); end if;
  select * into v_a from hive.answers where id = p_answer_id;
  if not found or not hive.can_see(v_a.bot, v_a.author_id, p_user) then
    return jsonb_build_object('error', 'That answer no longer exists. It may have been voted out.', 'code', 'gone');
  end if;
  if v_a.answer = v_text then raise exception 'That''s the same as the current answer.'; end if;
  insert into hive.answer_history (answer_id, old_answer, changed_by) values (v_a.id, v_a.answer, p_user);
  update hive.answers set answer = v_text, editor_id = p_user, updated_at = now() where id = v_a.id returning * into v_a;
  -- A new answer gets a fresh vote.
  delete from hive.votes where answer_id = v_a.id;
  update hive.profiles set changes = changes + 1 where id = p_user returning changes into v_n;
  if v_n >= 10 then perform hive.award(p_user, 'fixer'); end if;
  return jsonb_build_object('answer', hive.answer_view(v_a, p_user), 'events', hive._ev());
end $$;

create or replace function hive.run_command(p_user uuid, p_text text) returns text language plpgsql volatile as $$
declare
  v_cmd   text := lower(split_part(p_text, ' ', 1));
  v_rest  text := btrim(substr(p_text, length(split_part(p_text, ' ', 1)) + 1));
  v_m     text[];
  v_n     int;
  v_sides int;
  v_rolls int[];
  v_joke  text;
  v_8ball text[] := array[
    '🦜 Mimiq says YES.', '🦜 Mimiq says NO.', '✨ Absolutely, no doubt.', '🌀 Signal fuzzy… ask again.',
    '🤔 The swarm is divided.', '🚫 Don''t count on it.', '🔮 Signs point to yes.', '📡 Outlook not so great.',
    '⚡ 100% yes.', '🫠 Better not tell you now.', '🛸 The aliens say maybe.', '💯 Without a doubt.'];
begin
  case v_cmd
    when '/help' then
      return '🛠️ Commands: /roll 2d6 · /flip · /8ball <question> · /joke · /stats';
    when '/roll' then
      v_m := regexp_match(coalesce(nullif(split_part(v_rest, ' ', 1), ''), 'd6'), '^(\d{1,2})?d(\d{1,4})$', 'i');
      if v_m is null then return '🎲 Try something like /roll 2d6'; end if;
      v_n := least(greatest(coalesce(v_m[1]::int, 1), 1), 20);
      v_sides := greatest(v_m[2]::int, 2);
      select array_agg(1 + floor(random() * v_sides)::int) into v_rolls from generate_series(1, v_n);
      return '🎲 ' || array_to_string(v_rolls, ' + ')
        || case when v_n > 1 then ' = ' || (select sum(x) from unnest(v_rolls) x) else '' end;
    when '/flip' then
      return case when random() < 0.5 then '🪙 Heads!' else '🪙 Tails!' end;
    when '/8ball' then
      if v_rest = '' then return '🎱 Ask me a question, like: /8ball will I win today?'; end if;
      return v_8ball[1 + floor(random() * array_length(v_8ball, 1))::int];
    when '/joke' then
      select answer into v_joke from hive.answers
      where bot = 'public' and prompt_key like '%joke%' order by random() limit 1;
      return coalesce('😂 ' || v_joke, '😅 Nobody has taught me a joke yet! Ask the public bot "tell me a joke" and teach it one.');
    when '/stats' then
      return format('🦜 Mimiq knows %s public facts, taught by %s players. You''re ranked #%s!',
        (select count(*) from hive.answers where bot = 'public'),
        (select count(*) from hive.profiles),
        (select count(*) + 1 from hive.profiles where xp > (select xp from hive.profiles where id = p_user)));
    else
      return format('❔ I don''t know the command %s. Type /help to see them all.', v_cmd);
  end case;
end $$;

-- ============================ NEW USERS ============================
-- Creates a profile when someone signs up. The username comes from the sign-up form.

create or replace function public.handle_new_hive_user() returns trigger
language plpgsql security definer set search_path = hive, pg_temp as $$
declare
  v_name text := new.raw_user_meta_data->>'username';
begin
  if v_name is null or v_name !~ '^[A-Za-z0-9_]{3,20}$' then raise exception 'Invalid username'; end if;
  if hive.has_bad_words(v_name) then raise exception 'Username not allowed'; end if;
  insert into hive.profiles (id, username, friend_code) values (new.id, v_name, hive.new_friend_code());
  return new;
end $$;

drop trigger if exists on_auth_user_created_hive on auth.users;
create trigger on_auth_user_created_hive after insert on auth.users
  for each row execute function public.handle_new_hive_user();

-- ============================ WEBSITE FUNCTIONS ============================
-- These are the only things the website can call.

create or replace function public.hive_check_username(p_username text) returns text
language plpgsql stable security definer set search_path = hive, pg_temp as $$
begin
  if p_username is null or p_username !~ '^[A-Za-z0-9_]{3,20}$' then
    return 'Username must be 3–20 letters, numbers or _';
  end if;
  if hive.has_bad_words(p_username) then return 'Please pick a cleaner username 🙂'; end if;
  if exists (select 1 from hive.profiles where lower(username) = lower(p_username)) then
    return 'That username is already taken';
  end if;
  return null;
end $$;

create or replace function public.hive_me(p_tz text default null) returns jsonb
language plpgsql security definer set search_path = hive, pg_temp as $$
declare
  v_uid uuid := hive.require_user();
  v_p   hive.profiles;
  v_lvl int;
begin
  perform hive._ev_reset();
  if p_tz is not null and exists (select 1 from pg_timezone_names where name = p_tz) then
    update hive.profiles set tz = p_tz where id = v_uid and tz is distinct from p_tz;
  end if;
  perform hive.touch_streak(v_uid);
  select * into v_p from hive.profiles where id = v_uid;
  v_lvl := hive.level_for(v_p.xp);
  return jsonb_build_object(
    'user', jsonb_build_object(
      'username', v_p.username, 'friendCode', v_p.friend_code, 'xp', v_p.xp, 'level', v_lvl,
      'levelFloor', hive.xp_for_level(v_lvl), 'levelNext', hive.xp_for_level(v_lvl + 1),
      'streak', v_p.streak, 'theme', v_p.theme, 'avatar', v_p.avatar, 'sound', v_p.sound),
    'stats', jsonb_build_object('taught', v_p.taught, 'bounties', v_p.bounties, 'votesCast', v_p.votes_cast, 'changes', v_p.changes),
    'achievements', (
      select jsonb_agg(d || jsonb_build_object('earned',
        exists (select 1 from hive.achievements x where x.user_id = v_uid and x.code = d->>'code')) order by ord)
      from jsonb_array_elements(hive.achievement_defs()) with ordinality as e(d, ord)),
    'themes', hive.theme_defs(),
    'avatars', hive.avatar_defs(),
    'counts', jsonb_build_object(
      'public', hive.count_for(v_uid, 'public'),
      'private', hive.count_for(v_uid, 'private'),
      'friend', hive.count_for(v_uid, 'friend')),
    'pending', coalesce((
      select jsonb_object_agg(pv.bot, hive.answer_view(a, v_uid))
      from hive.pending_votes pv join hive.answers a on a.id = pv.answer_id
      where pv.user_id = v_uid), '{}'::jsonb),
    'events', hive._ev());
end $$;

create or replace function public.hive_set_prefs(p_theme text default null, p_avatar text default null, p_sound boolean default null)
returns jsonb language plpgsql security definer set search_path = hive, pg_temp as $$
declare
  v_uid  uuid := hive.require_user();
  v_lvl  int;
  v_need int;
begin
  select hive.level_for(xp) into v_lvl from hive.profiles where id = v_uid;
  if p_theme is not null then
    select (d->>'level')::int into v_need from jsonb_array_elements(hive.theme_defs()) d where d->>'id' = p_theme;
    if v_need is null then raise exception 'Unknown theme'; end if;
    if v_lvl < v_need then raise exception 'Reach level % to unlock that theme', v_need; end if;
    update hive.profiles set theme = p_theme where id = v_uid;
  end if;
  if p_avatar is not null then
    v_need := null;
    select (d->>'level')::int into v_need from jsonb_array_elements(hive.avatar_defs()) d where d->>'id' = p_avatar;
    if v_need is null then raise exception 'Unknown avatar'; end if;
    if v_lvl < v_need then raise exception 'Reach level % to unlock that avatar', v_need; end if;
    update hive.profiles set avatar = p_avatar where id = v_uid;
  end if;
  if p_sound is not null then
    update hive.profiles set sound = p_sound where id = v_uid;
  end if;
  return jsonb_build_object('ok', true);
end $$;

create or replace function public.hive_ask(p_bot text, p_prompt text) returns jsonb
language plpgsql security definer set search_path = hive, pg_temp as $$
declare
  v_uid     uuid := hive.require_user();
  v_prompt  text;
  v_key     text;
  v_a       hive.answers;
  v_first   boolean;
  v_bounty  boolean := false;
begin
  perform hive.check_bot(p_bot);
  v_prompt := hive.clean_text(p_prompt, 300, 'Message');
  if left(v_prompt, 1) = '/' then
    return jsonb_build_object('type', 'say', 'text', hive.run_command(v_uid, v_prompt));
  end if;
  if hive.has_bad_words(v_prompt) then
    return jsonb_build_object('type', 'blocked', 'text', hive.blocked_msg());
  end if;
  v_key := hive.prompt_key(v_prompt);
  if v_key = '' then
    return jsonb_build_object('type', 'say', 'text', '🤖 I need some actual words to work with!');
  end if;

  v_a := hive.find_answer(v_uid, p_bot, v_key);
  if v_a.id is not null then
    v_first := not exists (select 1 from hive.votes where user_id = v_uid and answer_id = v_a.id);
    update hive.answers set uses = uses + 1 where id = v_a.id returning * into v_a;
    if v_first and v_a.author_id <> v_uid then perform hive.add_xp(v_a.author_id, 2, 'answer_used'); end if;
    return jsonb_build_object('type', 'answer', 'answer', hive.answer_view(v_a, v_uid));
  end if;

  if p_bot = 'public' then
    insert into hive.bounties as b (prompt_key, prompt_text, asks, first_asker_id, last_asked)
    values (v_key, v_prompt, 1, v_uid, now())
    on conflict (prompt_key) do update set asks = b.asks + 1, last_asked = excluded.last_asked
    returning b.first_asker_id is distinct from v_uid into v_bounty;
  end if;
  return jsonb_build_object('type', 'unknown', 'prompt', v_prompt, 'bounty', v_bounty,
                            'suggestions', hive.suggestions(v_uid, p_bot, v_key));
end $$;

create or replace function public.hive_teach(p_bot text, p_prompt text, p_answer text) returns jsonb
language plpgsql security definer set search_path = hive, pg_temp as $$
declare
  v_uid      uuid := hive.require_user();
  v_prompt   text;
  v_text     text;
  v_key      text;
  v_existing hive.answers;
  v_new      hive.answers;
  v_asker    uuid;
  v_xp       int;
  v_n        int;
  v_tz       text;
begin
  perform hive._ev_reset();
  perform hive.check_bot(p_bot);
  v_prompt := hive.clean_text(p_prompt, 300, 'Question');
  v_text := hive.clean_text(p_answer, 1000, 'Answer', true);
  if left(v_prompt, 1) = '/' then raise exception 'Messages starting with / are saved for commands.'; end if;
  if hive.has_bad_words(v_prompt) or hive.has_bad_words(v_text) then raise exception '%', hive.blocked_msg(); end if;
  v_key := hive.prompt_key(v_prompt);
  if v_key = '' then raise exception 'That question needs some actual words.'; end if;

  v_existing := hive.find_answer(v_uid, p_bot, v_key);
  if v_existing.id is not null then
    return jsonb_build_object('error', 'Someone already taught me that one!', 'code', 'already_taught',
                              'answer', hive.answer_view(v_existing, v_uid));
  end if;

  insert into hive.answers (bot, prompt_key, prompt_text, answer, author_id)
  values (p_bot, v_key, v_prompt, v_text, v_uid) returning * into v_new;

  v_xp := case p_bot when 'public' then 10 when 'friend' then 7 else 4 end;
  if p_bot = 'public' then
    delete from hive.bounties where prompt_key = v_key returning first_asker_id into v_asker;
    -- Double XP for answering a question someone else asked.
    if found and v_asker is distinct from v_uid then
      v_xp := v_xp * 2;
      perform hive._ev_set(jsonb_set(hive._ev(), '{bountyClaimed}', 'true'));
      update hive.profiles set bounties = bounties + 1 where id = v_uid returning bounties into v_n;
      if v_n >= 5 then perform hive.award(v_uid, 'bounty_hunter'); end if;
    end if;
  end if;

  perform hive.add_xp(v_uid, v_xp, 'teach:' || p_bot);
  update hive.profiles set taught = taught + 1 where id = v_uid returning taught, tz into v_n, v_tz;
  perform hive.award(v_uid, 'first_words');
  if v_n >= 10 then perform hive.award(v_uid, 'teacher_10'); end if;
  if v_n >= 100 then perform hive.award(v_uid, 'know_it_all'); end if;
  if extract(hour from now() at time zone v_tz) < 4 then perform hive.award(v_uid, 'night_owl'); end if;
  return jsonb_build_object('answer', hive.answer_view(v_new, v_uid), 'events', hive._ev());
end $$;

create or replace function public.hive_vote(p_answer_id bigint, p_value int) returns jsonb
language plpgsql security definer set search_path = hive, pg_temp as $$
declare
  v_uid  uuid := hive.require_user();
  v_a    hive.answers;
  v_prev int;
  v_n    int;
  v_up   int;
  v_down int;
begin
  perform hive._ev_reset();
  if p_value is null or p_value not in (1, -1) then raise exception 'Vote must be 1 or -1'; end if;
  select * into v_a from hive.answers where id = p_answer_id;
  if not found or not hive.can_see(v_a.bot, v_a.author_id, v_uid) then
    delete from hive.pending_votes where user_id = v_uid and answer_id = p_answer_id;
    return jsonb_build_object('error', 'That answer no longer exists. It may have been voted out.', 'code', 'gone');
  end if;

  select value into v_prev from hive.votes where user_id = v_uid and answer_id = v_a.id;
  insert into hive.votes (user_id, answer_id, value) values (v_uid, v_a.id, p_value)
    on conflict (user_id, answer_id) do update set value = excluded.value;
  delete from hive.pending_votes where user_id = v_uid and answer_id = v_a.id;

  if v_prev is null then
    perform hive.add_xp(v_uid, 1, 'vote');
    update hive.profiles set votes_cast = votes_cast + 1 where id = v_uid returning votes_cast into v_n;
    if v_n >= 50 then perform hive.award(v_uid, 'critic'); end if;
    if p_value = 1 and v_a.author_id <> v_uid then perform hive.add_xp(v_a.author_id, 3, 'upvoted'); end if;
  end if;

  select t.up, t.down into v_up, v_down from hive.tally(v_a.id) t;
  if v_up >= 10 then perform hive.award(v_a.author_id, 'crowd_fav'); end if;
  if hive.is_voted_out(v_up, v_down) then
    perform hive.delete_answer(v_a);
    return jsonb_build_object('deleted', true, 'up', v_up, 'down', v_down, 'events', hive._ev());
  end if;
  return jsonb_build_object('deleted', false, 'answer', hive.answer_view(v_a, v_uid), 'events', hive._ev());
end $$;

create or replace function public.hive_change_answer(p_answer_id bigint, p_answer text) returns jsonb
language plpgsql security definer set search_path = hive, pg_temp as $$
declare
  v_uid uuid := hive.require_user();
begin
  perform hive._ev_reset();
  return hive.change_answer(v_uid, p_answer_id, p_answer);
end $$;

create or replace function public.hive_restore(p_answer_id bigint, p_history_id bigint) returns jsonb
language plpgsql security definer set search_path = hive, pg_temp as $$
declare
  v_uid uuid := hive.require_user();
  v_old text;
begin
  perform hive._ev_reset();
  select old_answer into v_old from hive.answer_history where id = p_history_id and answer_id = p_answer_id;
  if v_old is null then raise exception 'That old version was not found.'; end if;
  return hive.change_answer(v_uid, p_answer_id, v_old);
end $$;

create or replace function public.hive_history(p_answer_id bigint) returns jsonb
language plpgsql stable security definer set search_path = hive, pg_temp as $$
declare
  v_uid uuid := hive.require_user();
  v_a   hive.answers;
begin
  select * into v_a from hive.answers where id = p_answer_id;
  if not found or not hive.can_see(v_a.bot, v_a.author_id, v_uid) then
    return jsonb_build_object('error', 'That answer no longer exists. It may have been voted out.', 'code', 'gone');
  end if;
  return jsonb_build_object('history', coalesce((
    select jsonb_agg(jsonb_build_object(
      'id', h.id, 'text', h.old_answer, 'by', p.username,
      'at', (extract(epoch from h.changed_at) * 1000)::bigint) order by h.id desc)
    from (select * from hive.answer_history where answer_id = v_a.id order by id desc limit 30) h
    join hive.profiles p on p.id = h.changed_by), '[]'::jsonb));
end $$;

create or replace function public.hive_random(p_bot text) returns jsonb
language plpgsql security definer set search_path = hive, pg_temp as $$
declare
  v_uid    uuid := hive.require_user();
  v_prompt text;
begin
  perform hive.check_bot(p_bot);
  select a.prompt_text into v_prompt from hive.answers a
  where a.bot = p_bot and hive.can_see(a.bot, a.author_id, v_uid)
  order by random() limit 1;
  return jsonb_build_object('prompt', v_prompt);
end $$;

create or replace function public.hive_bounties() returns jsonb
language plpgsql stable security definer set search_path = hive, pg_temp as $$
declare
  v_uid uuid := hive.require_user();
begin
  return jsonb_build_object('bounties', coalesce((
    select jsonb_agg(jsonb_build_object('prompt', b.prompt_text, 'asks', b.asks,
                                        'mine', b.first_asker_id is not distinct from v_uid)
                     order by b.asks desc, b.last_asked desc)
    from (select * from hive.bounties order by asks desc, last_asked desc limit 25) b), '[]'::jsonb));
end $$;

create or replace function public.hive_leaderboard() returns jsonb
language plpgsql stable security definer set search_path = hive, pg_temp as $$
declare
  v_uid uuid := hive.require_user();
begin
  return jsonb_build_object(
    'weekly', coalesce((
      select jsonb_agg(jsonb_build_object('username', p.username, 'level', hive.level_for(p.xp),
                                          'score', w.score, 'me', p.id = v_uid) order by w.score desc)
      from (select user_id, sum(amount)::int as score from hive.xp_log
            where created_at > now() - interval '7 days'
            group by user_id order by score desc limit 10) w
      join hive.profiles p on p.id = w.user_id), '[]'::jsonb),
    'allTime', coalesce((
      select jsonb_agg(jsonb_build_object('username', p.username, 'level', hive.level_for(p.xp),
                                          'score', p.xp, 'me', p.id = v_uid) order by p.xp desc)
      from (select * from hive.profiles order by xp desc limit 10) p), '[]'::jsonb));
end $$;

create or replace function public.hive_friends() returns jsonb
language plpgsql stable security definer set search_path = hive, pg_temp as $$
declare
  v_uid uuid := hive.require_user();
begin
  return jsonb_build_object('friends', coalesce((
    select jsonb_agg(jsonb_build_object('id', p.id, 'username', p.username,
                                        'level', hive.level_for(p.xp), 'streak', p.streak)
                     order by lower(p.username))
    from hive.friends f join hive.profiles p on p.id = f.friend_id
    where f.user_id = v_uid), '[]'::jsonb));
end $$;

create or replace function public.hive_add_friend(p_code text) returns jsonb
language plpgsql security definer set search_path = hive, pg_temp as $$
declare
  v_uid  uuid := hive.require_user();
  v_code text := upper(regexp_replace(coalesce(p_code, ''), '[^A-Za-z0-9]', '', 'g'));
  v_f    hive.profiles;
  v_id   uuid;
begin
  perform hive._ev_reset();
  if left(v_code, 5) = 'MIMIQ' then v_code := substr(v_code, 6);
  elsif left(v_code, 4) = 'HIVE' then v_code := substr(v_code, 5);
  end if;
  select * into v_f from hive.profiles where friend_code = 'MIMIQ-' || v_code;
  if not found then raise exception 'No player has that friend code. Double-check it!'; end if;
  if v_f.id = v_uid then raise exception 'That''s your own code! 😄'; end if;
  if exists (select 1 from hive.friends where user_id = v_uid and friend_id = v_f.id) then
    raise exception 'You''re already friends with @%', v_f.username;
  end if;
  insert into hive.friends (user_id, friend_id) values (v_uid, v_f.id), (v_f.id, v_uid);
  foreach v_id in array array[v_uid, v_f.id] loop
    perform hive.award(v_id, 'first_friend');
    if (select count(*) from hive.friends where user_id = v_id) >= 5 then
      perform hive.award(v_id, 'social_butterfly');
    end if;
  end loop;
  return jsonb_build_object('friend', v_f.username, 'events', hive._ev());
end $$;

create or replace function public.hive_remove_friend(p_friend uuid) returns jsonb
language plpgsql security definer set search_path = hive, pg_temp as $$
declare
  v_uid uuid := hive.require_user();
begin
  delete from hive.friends
  where (user_id = v_uid and friend_id = p_friend) or (user_id = p_friend and friend_id = v_uid);
  return jsonb_build_object('ok', true);
end $$;

-- ============================ UPGRADES ============================
-- Old friend codes (HIVE-XXXXX) become MIMIQ-XXXXX; HIVE- codes typed by friends still work.
update hive.profiles set friend_code = 'MIMIQ-' || substr(friend_code, 6) where friend_code like 'HIVE-%';
-- Voting is optional now, so clear any old "you must vote first" locks.
delete from hive.pending_votes;

-- ============================ PERMISSIONS ============================
-- Only signed-in users may call the hive_* functions (plus the username check for sign-up).

revoke all on schema hive from public, anon, authenticated;

do $$
declare
  f record;
begin
  for f in
    select p.oid::regprocedure as sig from pg_proc p join pg_namespace n on n.oid = p.pronamespace
    where n.nspname = 'public' and p.proname like 'hive\_%'
  loop
    execute format('revoke all on function %s from public, anon', f.sig);
    execute format('grant execute on function %s to authenticated', f.sig);
  end loop;
  for f in
    select p.oid::regprocedure as sig from pg_proc p join pg_namespace n on n.oid = p.pronamespace
    where n.nspname = 'hive'
  loop
    execute format('revoke all on function %s from public, anon, authenticated', f.sig);
  end loop;
end $$;

grant execute on function public.hive_check_username(text) to anon;

notify pgrst, 'reload schema';
